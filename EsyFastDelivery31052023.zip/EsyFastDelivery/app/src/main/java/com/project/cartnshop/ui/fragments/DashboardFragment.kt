package com.project.cartnshop.ui.fragments

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.GridLayoutManager
import com.project.cartnshop.R
import com.project.cartnshop.adapter.DashboardListAdapter
import com.project.cartnshop.database.Database
import com.project.cartnshop.model.Product
import com.project.cartnshop.ui.activities.CartListActivity
import com.project.cartnshop.ui.activities.SettingsActivity
import com.project.cartnshop.ui.activities.ShopActivity
import kotlinx.android.synthetic.main.fragment_dashboard.*


class DashboardFragment : UiComponentsFragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)


    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        val root: View = inflater.inflate(R.layout.fragment_dashboard, container, false)
        getDashboardList("")
        val startForResult =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result: ActivityResult ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val intent = result.data
                    val shop: String? = intent?.getStringExtra("shop")
                    showProgressBar(getString(R.string.please_wait))

                    if (shop != null) {
                        Log.e("shop",shop)
                        Database().getItemsForShop(this@DashboardFragment, shop)
                    }

                }
            }

        val tvShops: TextView = root.findViewById(R.id.tvShops);
        tvShops.setOnClickListener {
            startForResult.launch(Intent(context, ShopActivity::class.java))
        }

        val tvGrocery: TextView = root.findViewById(R.id.tvGrocery);
        tvGrocery.setOnClickListener { getDashboardList("Grocery") }

        val tvFood: TextView = root.findViewById(R.id.tvFood);
        tvFood.setOnClickListener { getDashboardList("Food") }

        val tvFashion: TextView = root.findViewById(R.id.tvFashion);
        tvFashion.setOnClickListener { getDashboardList("Fashion") }

        val tvMedicine: TextView = root.findViewById(R.id.tvMedicine);
        tvMedicine.setOnClickListener { getDashboardList("Medicine") }

        val tvSkinCare: TextView = root.findViewById(R.id.tvSkinCare);
        tvSkinCare.setOnClickListener { getDashboardList("SkinCare") }

        val tvSports: TextView = root.findViewById(R.id.tvSports);
        tvSports.setOnClickListener { getDashboardList("Sports") }

        val tvToys: TextView = root.findViewById(R.id.tvToys);
        tvToys.setOnClickListener { getDashboardList("Toys") }

        val tvClothing: TextView = root.findViewById(R.id.tvClothing);
        tvClothing.setOnClickListener { getDashboardList("Clothing") }

        val tvCrafts: TextView = root.findViewById(R.id.tvCrafts);
        tvCrafts.setOnClickListener { getDashboardList("Crafts") }

        val etSearch: EditText = root.findViewById(R.id.etSearch)
        etSearch.doAfterTextChanged {
            if (etSearch.text.toString().length > 3) {
                showProgressBar(getString(R.string.please_wait))
                Database().getItemsForSearch(this@DashboardFragment, etSearch.text.toString())
            }

        }


        return root
    }

    override fun onResume() {
        super.onResume()

    }


    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.dashboard_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)

    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        when (id) {
            R.id.action_settings -> {
                startActivity(Intent(activity, SettingsActivity::class.java))
                return true
            }
            R.id.cartMenuButton -> {
                startActivity(Intent(activity, CartListActivity::class.java))
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    fun successDashboardList(dashboardList: ArrayList<Product>) {
        hideProgressBar()
        Log.e("size",""+dashboardList.size);
        if (dashboardList.size > 0) {
            tv_no_dashboard_items_found.visibility = View.GONE
            rv_dashboard_items.visibility = View.VISIBLE
            rv_dashboard_items.layoutManager = GridLayoutManager(activity, 2)
            rv_dashboard_items.setHasFixedSize(true)
            val adapterDashboard = DashboardListAdapter(requireActivity(), dashboardList)
            rv_dashboard_items.adapter = adapterDashboard
        } else {
            rv_dashboard_items.visibility = View.GONE
            tv_no_dashboard_items_found.visibility = View.VISIBLE
        }

    }

    private fun getDashboardList(cat: String) {

        showProgressBar(getString(R.string.please_wait))
        Database().getItemsForDashboard(this@DashboardFragment, cat)


    }


}