package com.project.cartnshop.adapter

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.project.cartnshop.ui.activities.OrderDetailsActivity
import com.project.cartnshop.R
import com.project.cartnshop.model.Order
import com.project.cartnshop.utils.LoadGlide
import kotlinx.android.synthetic.main.order_row.view.*

class OrderAdapter(private val context: Context,private var list: ArrayList<Order>): RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return OrderViewHolder(
        LayoutInflater.from(context).inflate(R.layout.order_row, parent, false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {

        val model = list[position]

        if (holder is OrderViewHolder) {

            LoadGlide(context).loadProductImage(
                model.image,
                holder.itemView.iv_item_image
            )

            holder.itemView.tv_item_name.text = model.title
            holder.itemView.tv_item_price.text = "₹${model.total_amount}"
            holder.itemView.ib_delete_product.visibility = View.GONE

            holder.itemView.setOnClickListener {
                val intent = Intent(context, OrderDetailsActivity::class.java)
                intent.putExtra("extra_order_details",model)
                context.startActivity(intent)
            }

            holder.itemView.tvFeedback.setOnClickListener {
showDialog()

            }
            holder.itemView.tvSupport.setOnClickListener {
                showContactDialog()

            }
        }

    }

    override fun getItemCount(): Int {
        return list.size
    }

    private fun showDialog() {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_feedback)

        val yesBtn = dialog.findViewById(R.id.btnSubmit) as AppCompatButton

        yesBtn.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()

    }

    private fun showContactDialog() {
        val dialog = Dialog(context)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_support)
        val tvPhone = dialog.findViewById(R.id.tvPhone) as TextView

        val tvEmail = dialog.findViewById(R.id.tvEmail) as TextView

        tvPhone.setOnClickListener {
            dialog.dismiss()
            val dialIntent = Intent(Intent.ACTION_DIAL)
            dialIntent.data = Uri.parse("tel:" + "9834214226")
            context.startActivity(dialIntent)
        }
        tvEmail.setOnClickListener {
            dialog.dismiss()


            val mIntent = Intent(Intent.ACTION_SEND)
            /*To send an email you need to specify mailto: as URI using setData() method
            and data type will be to text/plain using setType() method*/
            mIntent.data = Uri.parse("mailto:")
            mIntent.type = "text/plain"
            // put recipient email in intent
            /* recipient is put as array because you may wanna send email to multiple emails
               so enter comma(,) separated emails, it will be stored in array*/
            mIntent.putExtra(Intent.EXTRA_EMAIL, "krishnamadne123@gmail.com")
            //put the Subject in the intent
            mIntent.putExtra(Intent.EXTRA_SUBJECT, "Contact Support")
            //put the message in the intent
            mIntent.putExtra(Intent.EXTRA_TEXT, "Please write the issue")


            try {
                //start email intent
                context.startActivity(Intent.createChooser(mIntent, "Choose Email Client..."))
            }
            catch (e: Exception){

            }


        }

        dialog.show()

    }

}