package com.project.cartnshop.ui.activities

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.project.cartnshop.R
import kotlinx.android.synthetic.main.activity_payment.*

class PaymentActivity : UiComponentsActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        btn_place_order.setOnClickListener {
            Toast.makeText(
                this, getString(R.string.your_order_has_placed_success), Toast.LENGTH_LONG
            ).show()

            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}