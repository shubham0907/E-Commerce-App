package com.project.cartnshop.ui.activities

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.tasks.OnCompleteListener
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import com.google.firebase.auth.PhoneAuthProvider.ForceResendingToken
import com.google.firebase.auth.PhoneAuthProvider.OnVerificationStateChangedCallbacks
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.project.cartnshop.R
import com.project.cartnshop.database.Database
import com.project.cartnshop.model.User
import com.project.cartnshop.utils.Constants
import kotlinx.android.synthetic.main.activity_register.*
import java.util.concurrent.TimeUnit

class OTPActivity : AppCompatActivity() {
    private lateinit var mEt1: EditText
    private lateinit var mEt2: EditText
    private lateinit var mEt3: EditText
    private lateinit var mEt4: EditText
    private lateinit var mEt5: EditText
    private lateinit var mEt6: EditText
    private var mContext: Context? = null
    lateinit var btn_verify: Button
    lateinit var tv_phone_no: TextView

    var phone: String? = null
    private var mAuth: FirebaseAuth? = null
    private var verificationId: String? = null
    var sharedPreferences: SharedPreferences? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_otp)
        mAuth = FirebaseAuth.getInstance()
        initialize()
        phone = intent.getStringExtra("phone")
        sendVerificationCode("+91$phone")
        tv_phone_no!!.text = phone
        addTextWatcher(mEt1)
        addTextWatcher(mEt2)
        addTextWatcher(mEt3)
        addTextWatcher(mEt4)
        addTextWatcher(mEt5)
        addTextWatcher(mEt6)
    }

    private fun initialize() {
        tv_phone_no = findViewById(R.id.tv_phone_no)
        mEt1 = findViewById(R.id.otp_edit_text1)
        mEt2 = findViewById(R.id.otp_edit_text2)
        mEt3 = findViewById(R.id.otp_edit_text3)
        mEt4 = findViewById(R.id.otp_edit_text4)
        mEt5 = findViewById(R.id.otp_edit_text5)
        mEt6 = findViewById(R.id.otp_edit_text6)
        mContext = this@OTPActivity
        btn_verify = findViewById(R.id.btn_verify)
        btn_verify.setOnClickListener(View.OnClickListener {
            val otpCode = mEt1.getText().toString() + mEt2.getText().toString() + mEt3.getText()
                .toString() + mEt4.getText().toString() + mEt5.getText().toString() + mEt6.getText()
                .toString()
            verifyCode(otpCode)
        })
    }

    private fun addTextWatcher(one: EditText?) {
        one!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable) {
                when (one.id) {
                    R.id.otp_edit_text1 -> if (one.length() == 1) {
                        mEt2!!.requestFocus()
                    }
                    R.id.otp_edit_text2 -> if (one.length() == 1) {
                        mEt3!!.requestFocus()
                    } else if (one.length() == 0) {
                        mEt1!!.requestFocus()
                    }
                    R.id.otp_edit_text3 -> if (one.length() == 1) {
                        mEt4!!.requestFocus()
                    } else if (one.length() == 0) {
                        mEt2!!.requestFocus()
                    }
                    R.id.otp_edit_text4 -> if (one.length() == 1) {
                        mEt5!!.requestFocus()
                    } else if (one.length() == 0) {
                        mEt3!!.requestFocus()
                    }
                    R.id.otp_edit_text5 -> if (one.length() == 1) {
                        mEt6!!.requestFocus()
                    } else if (one.length() == 0) {
                        mEt4!!.requestFocus()
                    }
                    R.id.otp_edit_text6 -> if (one.length() == 1) {
                        val inputManager =
                            mContext!!.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                        inputManager.hideSoftInputFromWindow(
                            this@OTPActivity.currentFocus!!.windowToken,
                            InputMethodManager.HIDE_NOT_ALWAYS
                        )
                    } else if (one.length() == 0) {
                        mEt5!!.requestFocus()
                    }
                }
            }
        })
    }

    private fun sendVerificationCode(number: String) {
        // this method is used for getting
        // OTP on user phone number.
        val options =
            PhoneAuthOptions.newBuilder(mAuth!!).setPhoneNumber(number) // Phone number to verify
                .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                .setActivity(this) // Activity (for callback binding)
                .setCallbacks(mCallBack) // OnVerificationStateChangedCallbacks
                .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    // callback method is called on Phone auth provider.
    private val   // initializing our callbacks for on
    // verification callback method.
            mCallBack: OnVerificationStateChangedCallbacks =
        object : OnVerificationStateChangedCallbacks() {
            // below method is used when
            // OTP is sent from Firebase
            override fun onCodeSent(s: String, forceResendingToken: ForceResendingToken) {
                super.onCodeSent(s, forceResendingToken)
                // when we receive the OTP it
                // contains a unique id which
                // we are storing in our string
                // which we have already created.
                verificationId = s
            }

            // this method is called when user
            // receive OTP from Firebase.
            override fun onVerificationCompleted(phoneAuthCredential: PhoneAuthCredential) {
                // below line is used for getting OTP code
                // which is sent in phone auth credentials.
                val code = phoneAuthCredential.smsCode

                // checking if the code
                // is null or not.
                code?.let { verifyCode(it) }
            }

            // this method is called when firebase doesn't
            // sends our OTP code due to any error or issue.
            override fun onVerificationFailed(e: FirebaseException) {
                // displaying error message with firebase exception.
                Toast.makeText(this@OTPActivity, e.message, Toast.LENGTH_LONG).show()
            }
        }

    // below method is use to verify code from Firebase.
    private fun verifyCode(code: String) {
        // below line is used for getting
        // credentials from our verification id and code.
        val credential = PhoneAuthProvider.getCredential(verificationId!!, code)

        // after getting credential we are
        // calling sign in method.
        signInWithCredential(credential)
    }

    private fun signInWithCredential(credential: PhoneAuthCredential) {
        // inside this method we are checking if
        // the code entered is correct or not.
        mAuth!!.signInWithCredential(credential)
            .addOnCompleteListener(object : OnCompleteListener<AuthResult?> {
                override fun onComplete(task: Task<AuthResult?>) {
                    if (task.isSuccessful) {

                        val currentUser = Firebase.auth.currentUser


                        val user = User(currentUser!!.uid,"","","")
                        Database().registerUserOTP(this@OTPActivity, user)


                        Database().getCurrentUserDetails(this@OTPActivity)
                    } else {
                        // if the code is not correct then we are
                        // displaying an error message to the user.
                        Toast.makeText(
                            this@OTPActivity, task.exception!!.message, Toast.LENGTH_LONG
                        ).show()
                    }
                }
            })
    }

    fun userLoggedInSuccess(user: User) {

        val sharedPreferences = getSharedPreferences(Constants.SHOP_PREFERENCES, MODE_PRIVATE)
        val username = sharedPreferences.getString(Constants.CURRENT_NAME, "")
        val welcomeString: String = getString(R.string.welcome_user) + "$username"
        Toast.makeText(this, welcomeString, Toast.LENGTH_LONG).show()
        if (user.profileCompleted == 0) {
            val intent = Intent(this@OTPActivity, UserProfileActivity::class.java)
            intent.putExtra(Constants.EXTRA_USER_DETAILS, user)
            startActivity(intent)
        } else {
            startActivity(Intent(this@OTPActivity, DashboardActivity::class.java))
        }
        finish()
    }
}