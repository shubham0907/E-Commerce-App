package com.project.cartnshop.ui.activities

import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.project.cartnshop.R
import com.project.cartnshop.adapter.TimeLineAdapter
import com.project.cartnshop.model.OrderStatus
import com.project.cartnshop.model.TimeLineModel
import kotlinx.android.synthetic.main.activity_tracking.*

class TrackingActivity : UiComponentsActivity() {

    private lateinit var mAdapter: TimeLineAdapter
    private val mDataList = ArrayList<TimeLineModel>()
    private lateinit var mLayoutManager: LinearLayoutManager


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tracking)
        initRecyclerView()
        setDataListItems()

    }

    private fun setDataListItems() {
        val orderDate=intent.getStringExtra("orderDate").toString()
        mDataList.add(TimeLineModel("Item successfully delivered. Delivery Boy Ram 1800 345 100000", "", OrderStatus.INACTIVE))
        mDataList.add(TimeLineModel("Courier is out to delivery your order", "2023-05-12 08:00", OrderStatus.INACTIVE))
        mDataList.add(TimeLineModel("Item has reached courier facility at New Delhi", "2023-05-11 21:00", OrderStatus.INACTIVE))
        mDataList.add(TimeLineModel("Item has been given to the courier", "2023-05-11 18:00", OrderStatus.INACTIVE))
        mDataList.add(TimeLineModel("Item is packed and will dispatch soon", "2023-05-11 09:30", OrderStatus.INACTIVE))
        mDataList.add(TimeLineModel("Order is being readied for dispatch", "2023-05-11 08:00", OrderStatus.INACTIVE))
        mDataList.add(TimeLineModel("Order processing initiated", orderDate, OrderStatus.COMPLETED))
        mDataList.add(TimeLineModel("Order confirmed by seller", orderDate, OrderStatus.COMPLETED))
        mDataList.add(TimeLineModel("Order placed successfully", orderDate, OrderStatus.COMPLETED))
    }

    private fun initRecyclerView() {
        mLayoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        recyclerView.layoutManager = mLayoutManager
        mAdapter = TimeLineAdapter(mDataList)
        recyclerView.adapter = mAdapter
    }
}