package com.project.cartnshop.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.project.cartnshop.R
import com.project.cartnshop.model.Shop
import com.project.cartnshop.model.SoldProduct
import com.project.cartnshop.ui.activities.SoldProductsDetailsActivity
import com.project.cartnshop.utils.LoadGlide
import kotlinx.android.synthetic.main.item_shop.view.*
import kotlinx.android.synthetic.main.order_row.view.*

class ShopAdapter(private val context: Context, private var shopList: ArrayList<Shop>,
                  private val callback: AdapterCallback) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    class ShopViewHolder(view: View) : RecyclerView.ViewHolder(view)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ShopViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_shop, parent, false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val model = shopList[position]

        if (holder is ShopViewHolder) {

            holder.itemView.tvShop.text = model.name


            holder.itemView.setOnClickListener {



                callback.onResultSelected(shopList[position].name)

            }
        }
    }

    override fun getItemCount(): Int {
        return shopList.size
    }

    interface AdapterCallback {
        fun onResultSelected(result: String)
    }

}