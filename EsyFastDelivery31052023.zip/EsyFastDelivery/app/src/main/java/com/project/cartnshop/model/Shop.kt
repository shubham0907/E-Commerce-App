package com.project.cartnshop.model

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Shop(val name: String = ""): Parcelable{

    override fun toString(): String {
        return name
    }

}
