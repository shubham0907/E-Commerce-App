package com.project.cartnshop.ui.activities

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.project.cartnshop.R
import com.project.cartnshop.adapter.ShopAdapter
import com.project.cartnshop.adapter.ShopAdapter.AdapterCallback
import com.project.cartnshop.database.Database
import com.project.cartnshop.model.Shop
import kotlinx.android.synthetic.main.activity_shops.*

class ShopActivity : UiComponentsActivity(), ShopAdapter.AdapterCallback {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shops)
        setupActionBar()

        getSoldProductList()

    }

    private fun getSoldProductList() {
        showProgressBar(getString(R.string.please_wait))
        Database().getShopsList(this)
    }

    fun successShopList(soldProductList: ArrayList<Shop>) {
        hideProgressBar()
        if (soldProductList.size > 0) {


            rv_my_order_items.layoutManager = LinearLayoutManager(this)
            rv_my_order_items.setHasFixedSize(true)
            val soldProductsAdapter = ShopAdapter(this, soldProductList, this)
            rv_my_order_items.adapter = soldProductsAdapter
        }

    }


    private fun setupActionBar() {

        setSupportActionBar(toolbar_shop_activity)

        val actionBar = supportActionBar
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
            actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_arrow_back_ios_new_24)
        }
        toolbar_shop_activity.setNavigationOnClickListener { onBackPressed() }
    }

    override fun onResultSelected(result: String) {
        val resultIntent = Intent()
        resultIntent.putExtra("shop", result)
        setResult(Activity.RESULT_OK, resultIntent)
        finish()
    }
}