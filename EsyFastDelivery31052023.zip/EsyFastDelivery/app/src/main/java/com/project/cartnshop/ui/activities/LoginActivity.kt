package com.project.cartnshop.ui.activities

import android.app.ActionBar.LayoutParams
import android.app.Dialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Window
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase
import com.project.cartnshop.R
import com.project.cartnshop.database.Database
import com.project.cartnshop.model.User
import com.project.cartnshop.utils.Constants
import kotlinx.android.synthetic.main.activity_login.*
import kotlinx.android.synthetic.main.progress_bar.*


lateinit var myProgressDialog: Dialog
private lateinit var auth: FirebaseAuth

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        btn_login.setOnClickListener {
            loginUser()
        }

        auth = Firebase.auth
        val currentUser = auth.currentUser

        if (currentUser != null) {
            val intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
            finish()
        }

        tv_forgot_password.setOnClickListener {
            val intent = Intent(this, ForgotPasswordActivity::class.java)
            startActivity(intent)

        }


        @Suppress("DEPRECATION") if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }

        tv_register.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }

        btn_loginMobile.setOnClickListener {
            showDialog()
        }


    }

    private fun showDialog() {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setContentView(R.layout.dialog_phone_verify)

        val yesBtn = dialog.findViewById(R.id.btnAdd) as Button
        val edittext = dialog.findViewById(R.id.etPhone) as EditText

        yesBtn.setOnClickListener {
            if (edittext.text.toString().length == 10) {
                val intent = Intent(this, OTPActivity::class.java)
                intent.putExtra("phone", edittext.text.toString())
                startActivity(intent)
            } else {
                Toast.makeText(
                    applicationContext, "Please enter correct phone number", Toast.LENGTH_LONG
                ).show()
            }

        }

        dialog.show()


        val layoutParams = WindowManager.LayoutParams()
        layoutParams.copyFrom(dialog.getWindow()?.getAttributes())

        // setting width to 90% of display

        // setting width to 90% of display
        layoutParams.width = (LayoutParams.MATCH_PARENT)

        // setting height to 90% of display

        // setting height to 90% of display
        layoutParams.height = (LayoutParams.WRAP_CONTENT)
        dialog.window?.attributes = layoutParams

    }


    fun loginUser() {

        val email = et_email.text.toString()
        val password = et_password.text.toString()

        if (email != "" && password != "") {
            showProgressBar()
            auth.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->

                if (task.isSuccessful) {
                    Database().getCurrentUserDetails(this@LoginActivity)
                } else {
                    hideProgressBar()
                    Toast.makeText(
                        this, getString(R.string.login_failed_try_again), Toast.LENGTH_LONG
                    ).show()
                }
            }
        } else {
            hideProgressBar()
            Toast.makeText(this, getString(R.string.dont_leave_entries_blank), Toast.LENGTH_LONG)
                .show()
        }

    }


    private fun showProgressBar() {
        myProgressDialog = Dialog(this)
        myProgressDialog.setContentView(R.layout.progress_bar)
        myProgressDialog.tv_progress_text.setText(R.string.please_wait)
        myProgressDialog.setCancelable(false)
        myProgressDialog.setCanceledOnTouchOutside(false)
        myProgressDialog.show()
    }

    private fun hideProgressBar() {
        myProgressDialog.dismiss()
    }

    fun userLoggedInSuccess(user: User) {
        hideProgressBar()
        val sharedPreferences = getSharedPreferences(Constants.SHOP_PREFERENCES, MODE_PRIVATE)
        val username = sharedPreferences.getString(Constants.CURRENT_NAME, "")
        val welcomeString: String = getString(R.string.welcome_user) + "$username"
        Toast.makeText(this, welcomeString, Toast.LENGTH_LONG).show()
        if (user.profileCompleted == 0) {
            val intent = Intent(this@LoginActivity, UserProfileActivity::class.java)
            intent.putExtra(Constants.EXTRA_USER_DETAILS, user)
            startActivity(intent)
        } else {
            startActivity(Intent(this@LoginActivity, DashboardActivity::class.java))
        }
        finish()
    }


}